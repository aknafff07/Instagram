<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM siswa WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($siswa = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top navbar-light bg-light">
    <div class="container">
        <a href="#" class="navbar-brand"><img src="foto/logo1.jpg" style="border-radius: 50%;" width="50px" height="50px" alt=""></a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active">Home</a>
                <button data-bs-toggle="modal" data-bs-target="#exampleModal" id="myButton" style="background: none; color:black;border-radius: 100px;border:none;">Tambah</button>
            </div>
            <form class="d-flex">
                <div class="input-group">                    
                    <!-- <img src="foto/logo.png" style="width:230px;height:80px;" alt=""> -->
                    <h2>LuxCountry</h2>
                </div>
            </form>
            <div class="navbar-nav">
                <a href="logout.php" class="nav-item nav-link"><button class="btn" style="background-color: #20c997; color:#fff;border-radius: 3px;border:none;">Logout</button></a>
            </div>
        </div>
    </div>
</nav>
<br><br><br><br>

<div class="container">
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $siswa['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $siswa['gambar'] ?>">
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="foto" id="" value="<?= $siswa['gambar'] ?>" ><br>
        <img src="images/<?= $siswa['gambar'] ?>" width="200" alt="" ><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>

        <input class="form-control" type="text" name="caption"value="<?= $siswa['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $siswa['lokasi'] ?>" id="" autocomplete="off"><br>

        <input class="btn" style="background-color: #20c997; color: #fff;" type="submit" value="Simpan" name="update">
    </form>
    </div>
</body>
</html>

<?php } ?>