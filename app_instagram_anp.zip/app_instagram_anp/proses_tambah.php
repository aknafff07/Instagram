<?php

include "koneksi.php";
require "function.php";

if (isset($_POST['simpan'])) {

    $gambar = upload(); 
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    
    $sql = "INSERT INTO siswa (gambar,caption,lokasi) VALUES ('$gambar', '$caption','$lokasi')";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("location:index.php?tambah=sukses");
    } else {
        header("location:index.php?tambah=gagal");
    }
}


?>