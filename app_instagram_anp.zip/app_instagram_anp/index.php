<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";
$sql = "SELECT * FROM siswa ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LuxCountry</title>
    <link rel="icon" type="image/x-icon" href="foto/logo1.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .geeks {
            width: 370px;
            height: 300px;
            overflow: hidden;
            margin: 0 auto;
        }
     
        .geeks img {
            width: 100%;
            transition: 0.5s all ease-in-out;
        }
     
        .geeks:hover img {
            transform: scale(1.5);
        }

        .popup {
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            display: none;
        }
        .popup-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888888;
            width: 30%;
            font-weight: bolder;
        }
        .popup-content button {
            display: block;
            margin: 0 auto;
            border: none;
        }
        .show {
            display: block;
        }
        h1 {
            color: green;
        }
        h2{
            font-family: "Times New Roman", Times, serif;
            font-size: 40px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top navbar-light shadow p-2 mb-5 bg-body-tertiary rounded">
    <div class="container">
        <a href="#" class="navbar-brand"><img src="foto/logo1.jpg" style="border-radius: 50%;" width="50px" height="50px" alt=""></a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active">Home</a>
                <!-- <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background: none; color:black;border-radius: 100px;border:none;">Tambah</button> -->
            </div>
            <form class="d-flex">
                <div class="input-group">                    
                    <!-- <img src="foto/logo.png" style="width:230px;height:80px;" alt=""> -->
                    <h2>LuxCountry</h2>
                </div>
            </form>
            <div class="navbar-nav">
                <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background: none; color:black;border-radius: 100px;border:none;"><i class="fa fa-plus" style="font-size:24px; color: #20c997;"></i></button>
                <a href="logout.php" class="nav-item nav-link"><button class="btn" style="background-color: #20c997; color:#fff;border-radius: 3px;border:none;">Logout</button></a>
                <!-- <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background: none; color:black;border-radius: 100px;border:none;">Tambah</button> -->
            </div>
        </div>
    </div>
</nav>
<br><br><br><br>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Lux Country</h1>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" class="p-3 mt-3" enctype="multipart/form-data">
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="foto" id="" required><br>

        <label class="form-label" for="">Caption</label>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br>
        
        <input class="btn" style="background-color: #20c997; color:#fff;" type="submit" value="Simpan" name="simpan">
    </form>
      </div>
    </div>
  </div>
</div>



    <div class="container">
    <?php while($siswa = mysqli_fetch_assoc($query)) { ?>
        <center>
        <div class="col-md-4">
            <div class="card">
              <div class="geeks">
                <img class="card-img-top" src="images/<?= $siswa['gambar'] ?>" alt="Card image cap" style="width:390px;height:300px;">
                </div>
            <div class="card-body card-body-cascade text-center pb-0">
                <h5 class="blue-text pb-2"><strong><?= $siswa['caption'] ?></strong></h5>
                <p class="card-text"><?= $siswa['lokasi'] ?></p>
                <!-- <i class="fa fa-heart-o" style="font-size:25px;color:red"></i> -->
                <button style="border:none; background: none; color: red;" class="hapus" id="<?=$siswa['no']?>">Hapus</button>
                <!-- <a href="hapus.php?no=<?=$siswa['no']?>" class="px-2 fa-lg li-ic"><i class="fa fa-trash" style="font-size:24px; color: #dc3545;"></i></a> -->
                <!-- <a href="edit.php?no=<?=$siswa['no']?>" class="px-2 fa-lg tw-ic"><i class="fa fa-pencil" style="font-size:24px;"></i></i></a> -->
                <button type="button" class="px-2 fa-lg tw-ic" style="border:none; background:none;" data-bs-toggle="modal" data-bs-target="#exampleModal<?=$siswa['no']?>"><i class="fa fa-pencil" style="font-size:24px; color: blue;"></i></button>
            <div class="card-footer text-muted text-center mt-4">@luxcountry_2324</div>
            </div>
            </div>
        </div><br>
        </center>

<div class="modal fade" id="exampleModal<?=$siswa['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Lux Country</h1>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $siswa['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $siswa['gambar'] ?>">
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="foto" id="" value="<?= $siswa['gambar'] ?>" ><br>
        <img src="images/<?= $siswa['gambar'] ?>" width="200" alt="" ><br><br>

        <label class="form-label" for="">Caption</label>
        <input class="form-control" type="text" name="caption"value="<?= $siswa['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $siswa['lokasi'] ?>" id="" autocomplete="off"><br>

        <input class="btn" style="background-color: #20c997; color: #fff;" type="submit" value="Simpan" name="update">
        </form>
      </div>
    </div>
  </div>
</div>
        
    <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
        document.addEventListener('DOMContentLoaded', function () {
            // Menggunakan event delegation untuk menangani klik pada tombol hapus
            document.body.addEventListener('click', function (e) {
                if (e.target.classList.contains('hapus')) {
                    const id = e.target.getAttribute('id');
                    Swal.fire({
                        title: 'Yakin ingin menghapus data?',
                        text: "Data yang dihapus tidak dapat dikembalikan!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Ya, Hapus!',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Tambahkan kode PHP Anda di sini untuk menghapus data berdasarkan ID
                            window.location.href='hapus.php?no=' + id;
                            // Contoh: window.location.href = 'hapus_data.php?id=' + id;
                            Swal.fire(
                                'Data Dihapus!',
                                'Data telah berhasil dihapus.',
                                'success'
                            )
                        }
                    });
                }
            });
        });
    </script>


<!-- <?php if(@$_SESSION['sukses']) { ?>
    <script>
        Swal.fire({
            icon:'succes',
            tittle:'sukses',
            text: 'data berhasil dihapus',
            timer: 3000,
            showConfirmButton: false
        })
    </script>
<?php unset($_SESSION['sukses']); } ?>
<script type="text/javascript">
    function hapus(){
    Swal.fire({
  title: 'Do you want to save the changes?',
  showDenyButton: true,
  showCancelButton: true,
  confirmButtonText: 'Save',
  denyButtonText: `Don't save`,
    }).then((result) => {
    /* Read more about isConfirmed, isDenied below */
    if (result.isConfirmed) {
        Swal.fire('Saved!', '', 'success')
    } else if (result.isDenied) {
        Swal.fire('Changes are not saved', '', 'info')
    }
    });
}
</script> -->
</body>
</html>